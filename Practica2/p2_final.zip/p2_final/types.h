#ifndef TYPES_H
#define TYPES_H
enum {NO_FINISHED, FINISHED};
#endif