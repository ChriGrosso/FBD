#include "utils.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

int no_deleted_registers = NO_DELETED_REGISTERS;

int string_compare(const char *s1, const char *s2) {
    int i;
    int cmp = 0;
    for (i = 0; i < PK_SIZE;i++) {
        cmp = s1[i]-s2[i];
        if(cmp)
            return cmp;
    }
    return 0;
}
bool check_dat(const char* filename) {
    size_t len = strlen(filename);
    if(filename == NULL || !(filename[len-3] == 'd' && filename[len-2] == 'a' && filename[len-1] == 't'))
        return false;
    return true;
}
void replaceExtensionByIdx(const char *fileName, char * indexName) {
    size_t len = strlen(fileName);
    strcpy(indexName,fileName);
    indexName[len-3] = 'i';
    indexName[len-2] = 'd';
    indexName[len-1] = 'x';
    return;
}


bool createTable(const char * tableName) {
    FILE *f = NULL;
    int a = -1;
    
    if(check_dat(tableName) == false)
        return false;
    
    f = fopen(tableName,"rb+");
    if(f != NULL) {
        printf("Archivo ya existe\n");
        fclose(f);
        return false;
    }

    if((f = fopen(tableName,"wb+")) == NULL)
        return false;
        
    fwrite(&a,sizeof(int),1,f );
    fclose(f);
    return createIndex(tableName);
    
}

bool createIndex(const char *indexName) {
    FILE *f = NULL;
    int a = -1;
    char *indexName_Rep = (char*) malloc((strlen(indexName)+1)* sizeof(char));

    if(indexName_Rep == NULL)
        return false;
    replaceExtensionByIdx(indexName,indexName_Rep);


    if((f = fopen(indexName_Rep,"rb+")) == NULL) {
        if((f = fopen(indexName_Rep,"wb+")) == NULL) {
            free(indexName_Rep);
            return false;
        }
        fwrite((void*)&a,sizeof(int),1,f );
        fwrite((void*)&a,sizeof(int),1,f);
        fclose(f);
    }

    free(indexName_Rep);
    return true;

}
void printnode(size_t _level, size_t level, FILE * indexFileHandler, int node_id, char side) {

    Node currentNode;
    size_t i;
    char key[5];

    if (node_id == -1 || _level > level) {
        return; 
    }

    fseek(indexFileHandler,sizeof(int)*2,SEEK_SET);
    
    if(fseek(indexFileHandler, node_id * (sizeof(int)*4 + sizeof(char)*4), SEEK_CUR) !=0) {
        printf("ERROR al buscar nodo\n");
        return;
    }


    fread(key,sizeof(char),4,indexFileHandler);
    fread(&currentNode.left,sizeof(int),1,indexFileHandler);
    fread(&currentNode.right,sizeof(int),1,indexFileHandler);
    fread(&currentNode.parent,sizeof(int),1,indexFileHandler);
    fread(&currentNode.offset,sizeof(int),1,indexFileHandler);

    for (i = 0; i < _level; i++) {
        printf("\t"); 
    }
    key[4] = '\0';
    if(side != '\0')
        printf("%c %s (%d): %d\n", side,key, node_id, currentNode.offset);
    else
        printf("%s (%d): %d\n", key, node_id, currentNode.offset);
    
    printnode(_level + 1, level, indexFileHandler, currentNode.left, 'l'); /* left*/
    printnode(_level + 1, level, indexFileHandler, currentNode.right, 'r'); /* right*/
    return;
}

void printTree(size_t level, const char * indexName)
{
    FILE *f;
    int aux;
    if(indexName == NULL)
        return;

    f = fopen(indexName, "rb");
    
    if (f == NULL) {
        return;
    }

    fread(&aux,sizeof(int),1,f);
    fread(&aux,sizeof(int),1,f);

    printnode(0, level, f, 0, '\0'); 
    fclose(f);
    return;
}

bool findKey(const char * book_id, const char *indexName,
             int * nodeIDOrDataOffset)
 {
    FILE *f;
    int currentOffset = 0, cmp;
    int last_node;
    Node currentNode;
    
    if((f = fopen(indexName,"rb+")) == NULL)
        return false;
    
    fread(&currentOffset,sizeof(int),1,f);
    fseek(f,sizeof(int)*2,SEEK_SET);
    
    while (currentOffset != -1) {

    if(fseek(f,currentOffset * sizeof(Node) + sizeof(int)*2, SEEK_SET) !=0) {
        printf("ERROR al buscar nodo\n");
        fclose(f);
        return false;
    }
        fread(currentNode.book_id,sizeof(char),4,f);
        fread(&currentNode.left,sizeof(int),1,f);
        fread(&currentNode.right,sizeof(int),1,f);
        fread(&currentNode.parent,sizeof(int),1,f);
        fread(&currentNode.offset,sizeof(int),1,f);

        cmp = string_compare(book_id,currentNode.book_id);
        if(!cmp) {
            *nodeIDOrDataOffset = currentNode.offset;
            fclose(f);
            return true;
        }

        if(cmp < 0) {
            last_node = currentOffset;
            currentOffset = currentNode.left;
        }    
        else {
            last_node = currentOffset;
            currentOffset = currentNode.right;
        }
    }

    *nodeIDOrDataOffset = last_node;
    fclose(f);
    return false;
 }

bool addIndexEntry(char * book_id,  int bookOffset, char const * indexName) {
    FILE *f;
    int parentOffset;
    if((f = fopen(indexName,"ab+")) == NULL)
        return false;
    printf("book_id: %s\n",book_id);
    if(findKey(book_id,indexName,&parentOffset) == true) {
        fclose(f);
        return false;
    }
    fseek(f,0,SEEK_END);
    fwrite(&bookOffset,sizeof(int),1,f);
    fwrite(book_id,sizeof(char),4,f);
    fwrite(book_id,sizeof(char),4,f);
    fclose(f);
    return true;
}

bool addTableEntry(Book * book, const char * dataName,
                   const char * indexName) {
    
    FILE *f;
    int offset = -1;
    int lenTitle;
    printf("%s\n",book->book_id);
    if((f = fopen(dataName,"ab+")) == NULL) {
        printf("Error al abrir archivo\n");
        return false;
    }
    
    if(findKey(book->book_id,indexName, &offset) == true) {
        printf("El libro ya existe\n");
        fclose(f);
        return false;
    }
    /*comprobar si hay registro borrado*/


    /*************/

    fseek(f,0,SEEK_END);
    lenTitle = strlen (book->title ) ;
    fwrite ( book->book_id , PK_SIZE, 1 , f ) ;
    fwrite ( &lenTitle ,sizeof ( int ) , 1 , f ) ;
    fwrite ( book->title ,lenTitle , 1 , f ) ;
    fclose(f);

    addIndexEntry(book->book_id,offset,indexName);
    return true;
}